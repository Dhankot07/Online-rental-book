-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 13, 2025 at 11:59 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rental_book`
--

-- --------------------------------------------------------

--
-- Table structure for table `book_cart`
--

CREATE TABLE `book_cart` (
  `cart_id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `book_id` int(10) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `book_cart`
--

INSERT INTO `book_cart` (`cart_id`, `user_id`, `book_id`, `is_deleted`) VALUES
(1, 1, 1, 1),
(2, 1, 3, 1),
(3, 1, 2, 1),
(5, 1, 3, 1),
(6, 1, 1, 1),
(7, 1, 5, 1),
(8, 1, 2, 1),
(9, 1, 7, 1),
(10, 1, 6, 1),
(11, 1, 6, 1),
(12, 1, 10, 1),
(13, 1, 12, 1),
(14, 2, 11, 1),
(15, 2, 3, 1),
(16, 2, 5, 1),
(17, 2, 4, 1),
(18, 2, 6, 1),
(19, 2, 6, 1),
(20, 2, 6, 1),
(21, 2, 6, 1),
(22, 2, 8, 1),
(23, 2, 9, 1),
(24, 3, 6, 1),
(25, 3, 6, 1),
(26, 3, 6, 1),
(27, 3, 6, 1),
(28, 3, 9, 1),
(29, 2, 9, 1),
(30, 2, 3, 1),
(31, 2, 5, 1),
(32, 2, 8, 1),
(33, 2, 13, 1),
(34, 2, 6, 1),
(35, 2, 13, 0),
(36, 3, 4, 1);

-- --------------------------------------------------------

--
-- Table structure for table `book_image`
--

CREATE TABLE `book_image` (
  `image_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `image` varchar(9000) NOT NULL,
  `is_deleted` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `book_image`
--

INSERT INTO `book_image` (`image_id`, `book_id`, `image`, `is_deleted`) VALUES
(1, 2, 'banner.jpg', 1),
(2, 2, 'banner2.jpg', 1),
(3, 5, 'livingroom.jpg', 1),
(5, 5, 'lamps.jpg', 1),
(6, 2, 'banner2.jpg', 1),
(7, 2, 'walllight.jpg', 1),
(8, 2, 'banner2.jpg', 1),
(9, 3, 'Think_like_a_monk_1st_edition.jpg', 0),
(10, 4, 'Dont_Believe_Everything_You_Think .jpg', 0),
(11, 6, 'Deep Work.jpg', 0),
(12, 7, 'Sapiens THE MULTI MILLION COPY BESTSELLER.jpg', 0),
(13, 8, 'A Man Called Ove.jpg', 0),
(14, 9, 'you only live once.jpg', 0),
(15, 13, 'Indian Economy.jpg', 0),
(16, 5, 'The Alchemist.jpg', 0),
(17, 2, 'the_power_of_your_sub_mind.jpg', 1),
(18, 4, 'Dont_Believe_Everything_You_Think2.jpg', 0),
(19, 4, 'Dont_Believe_Everything_You_Think3.jpg', 0),
(20, 4, 'Dont_Believe_Everything_You_Think4.jpg', 0),
(21, 2, 'the_power_of_your_sub_mind.jpg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `book_list`
--

CREATE TABLE `book_list` (
  `book_id` int(10) NOT NULL,
  `book_title` varchar(300) NOT NULL,
  `book_lang` varchar(20) NOT NULL,
  `book_author` varchar(50) NOT NULL,
  `publication` varchar(100) NOT NULL,
  `mrp` int(10) NOT NULL,
  `date` varchar(10) NOT NULL,
  `book_detail` varchar(1000) NOT NULL,
  `most_pop` int(1) NOT NULL,
  `available` int(1) NOT NULL,
  `is_deleted` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `book_list`
--

INSERT INTO `book_list` (`book_id`, `book_title`, `book_lang`, `book_author`, `publication`, `mrp`, `date`, `book_detail`, `most_pop`, `available`, `is_deleted`) VALUES
(1, 'Rich Dad Poor Dad : What the Rich Teach Their Kids About Money', 'English', 'Robert T. Kiyosaki', 'Harper', 100, '2022-01-01', 'Rich Dad Poor Dad is Robert\'s story of growing up with two dads — his real father and the father of his best friend, his rich dad — and the ways in which both men shaped his thoughts about money and investing. The book explodes the myth that you need to earn a high income to be rich and explains the difference between working for money and having your money work for you.\r\n', 0, 1, 1),
(2, 'The Power of Your Subconscious Mind', 'English', 'Joseph Murphy', 'Bookbuggs', 100, '2022-01-01', 'This remarkable book by Dr. Joseph Murphy, one of the pioneering voices of affirmative thinking, will unlock for you the truly staggering powers of your subconscious mind. Combining time-honored spiritual wisdom with cutting edge scientific research, Dr. Murphy explains how the subconscious mind influences every single thing that you do and how, by understanding it and learning to control its incredible force, you can improve the quality of your daily life.Everything, from the promotion that you wanted and the raise you think you deserve, to overcoming phobias and bad habits and strengthening interpersonal relationships, the Power of Your Subconscious Mind will open a world of happiness, success, prosperity and peace for you. It will change your life and your world by changing your beliefs.', 0, 1, 0),
(3, 'Think Like a Monk 1st edition', 'English', 'Jay Shetty', 'Bookbuggs', 80, '2020-04-14', 'Jay Shetty, social media superstar and host of the #1 podcast ‘On Purpose’, distils the timeless wisdom he learned as a practising monk into practical steps anyone can take every day to live a less anxious, more meaningful life.\r\nOver the past three years, Jay Shetty has become one of the world’s most popular influencers. One of his clips was the most watched video on Facebook last year, with over 360 million views. His social media following totals over 32 million, he has produced over 400 viral videos, which have amassed more than 5 billion views, and his podcast, ‘On Purpose’, is consistently ranked the world’s #1 health-related podcast.\r\nIn this inspiring, empowering book, Shetty draws on his time as a monk in the Vedic tradition to show us how we can clear the roadblocks to our potential and power. Drawing on ancient wisdom and his own rich experiences in the ashram, “Think Like a Monk” reveals how to overcome negative thoughts and habits, and access the calm and purpose that lie ', 1, 0, 0),
(4, 'Dont Believe Everything You Think ', 'English', 'Joseph Murphy', 'Harper', 90, '2022-11-25', ' uncovers the core of psychological suffering and offers insights to effortlessly shape the life you crave. Learn to detach from negativity, embrace love and joy, escape negative thought cycles, and tap into inner wisdom. The message is clear: anyone can attain peace, love, and fulfillment, irrespective of their history. Its not about rewiring your brain, but expanding your consciousness for lasting transformation. Within this book, delve into the core of emotional suffering and receive insig\'hts on effortlessly curating the life you aspire to.', 0, 1, 0),
(5, ' The Alchemist', 'English', 'Paulo Coelho', 'Harper', 100, '2005-10-17', 'Paulo Coelhos enchanting novel has inspired a devoted following around the world. This story, dazzling in its powerful simplicity and inspiring wisdom, is about an Andalusian shepherd boy named Santiago who travels from his homeland in Spain to the Egyptian desert in search of a treasure buried in the Pyramids. Along the way he meets a Gypsy woman, a man who calls himself', 1, 1, 0),
(6, 'Deep Work: Rules for Focused Success in a Distracted World [Paperback] Newport', 'English', 'Cal Newport ', 'Harper', 100, '2016-01-01', 'Cal Newport discusses in his new book, Deep Work: Rules For Focused Success In A Distracted World, about how professionals of today have started valuing quantity over quality; and how this has turned young professionals of today into puppets who try to indulge in extensive multitasking, dealing with multiple emails and projects. This prevents them from doing \'deep work\'; which is focused work free from all other distractions. This also means that the professionals of today should sort out their priorities.', 0, 0, 0),
(7, 'Sapiens THE MULTI-MILLION COPY BESTSELLER', 'English', 'Yuval Noah Harari ', 'Bookbuggs', 100, '2015-11-01', 'One of the world\'s preeminent historians and thinkers, Yuval Noah Harari challenges everything we know about being human.', 0, 0, 0),
(8, 'A Man Called Ove', 'English', 'Fredrik Backman', 'Bookbuggs', 100, '2016-11-17', 'The million-copy bestselling phenomenon, Fredrik Backman\'s heartwarming debut is a funny, moving, uplifting tale of love and community that will leave you with a spring in your step. Perfect for fans of Rachel Joyce\'s The Unlikely Pilgrimage of Harold Fry, Graeme Simsion\'s The Rosie Project and David Nicholl\'s US. New York Times bestseller\'Warm, funny, and almost unbearably moving\' Daily Mail\'Rescued all those men who constantly mean to read novels but never get round to it\' Spectator Books of the YearAt first sight, Ove is almost certainly the grumpiest man you will ever meet.', 0, 1, 0),
(9, 'YOU ONLY LIVE ONCE', 'English', 'Stuti Changella', 'Harper', 120, '2020-01-25', 'You are one person. Aren\'t you? But you are not the same person to each of them.\r\n\r\nFind the answers about your own life in this story about searching for love and discovering yourself. Join a broken but rising YouTube star Alara, a struggling but hopeful stand-up comedian Aarav, and a zany but zen beach shack owner Ricky. Together, take the journey to seek the truth behind the famous singer Elisha\'s disappearance somewhere by the deep sea in Goa.', 0, 0, 0),
(10, 'demo ', 'English', 'Robert T. Kiyosaki', 'Bookbuggs', 50, '2020-06-23', 'xyzzzz', 0, 0, 1),
(11, 'demo 31', 'English', 'fwefjewnfjo', 'Bookbuggs', 60, '2024-01-02', 'kjdvvgejgvkegv', 0, 0, 1),
(12, 'Rich Dad Poor Dad : What the Rich Teach Their Kids About Moneysfxgv', 'English', 'Robert T. Kiyosaki', 'PLATA PUBLISHING', 100, '2024-08-23', 'ghbghbdfh hth ', 0, 0, 1),
(13, 'Indian Economy 8th Edition', 'English', 'Vivek Singh', 'PLATA PUBLISHING', 150, '2023-01-07', 'This book is a comprehensive guide for GS Paper III, covering both Prelims and Mains, with a focus on economic development. It includes the latest Budget 2024-25, Economic Survey 2023-24, and updated current issues. Conceptual clarity is ensured through diagrams, graphs, and examples. The book features previous UPSC questions, economic terms for easy reference, and highlights important keywords. It also covers the syllabus for State PCS, RBI, NABARD, and SEBI exams.', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `book_order`
--

CREATE TABLE `book_order` (
  `order_id` int(100) NOT NULL,
  `user_id` int(10) NOT NULL,
  `b_id` int(11) NOT NULL,
  `quantity` int(1) NOT NULL,
  `payment` int(100) NOT NULL,
  `starting_date` date NOT NULL,
  `ending_date` date NOT NULL,
  `is_deleted` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `book_order`
--

INSERT INTO `book_order` (`order_id`, `user_id`, `b_id`, `quantity`, `payment`, `starting_date`, `ending_date`, `is_deleted`) VALUES
(1, 1, 1, 1, 100, '2024-08-14', '2024-08-14', 1),
(2, 1, 3, 1, 80, '2024-08-14', '2024-08-29', 1),
(3, 1, 2, 1, 100, '2024-08-14', '2024-08-14', 1),
(4, 1, 3, 1, 80, '2024-08-14', '2024-08-29', 1),
(5, 1, 1, 1, 100, '2024-08-14', '2024-08-29', 0),
(6, 1, 5, 1, 100, '2024-08-14', '2024-08-29', 1),
(7, 1, 2, 1, 100, '2024-08-14', '2024-08-29', 0),
(8, 1, 7, 1, 100, '2024-08-14', '2024-08-29', 1),
(9, 1, 6, 1, 100, '2024-08-15', '2024-08-30', 1),
(10, 1, 10, 1, 50, '2024-08-19', '2024-09-03', 1),
(11, 2, 3, 1, 80, '2024-09-03', '2024-09-10', 1),
(12, 2, 5, 1, 100, '2024-09-03', '2024-09-03', 1),
(13, 2, 4, 1, 90, '2024-09-03', '2024-09-03', 1),
(14, 2, 6, 1, 100, '2024-09-03', '2024-09-18', 1),
(15, 2, 6, 1, 100, '2024-09-03', '2024-09-18', 1),
(16, 2, 6, 1, 100, '2024-09-03', '2024-09-18', 1),
(17, 2, 6, 1, 100, '2024-09-03', '2024-09-18', 1),
(19, 3, 6, 1, 100, '2024-09-03', '2024-09-03', 1),
(20, 3, 6, 1, 100, '2024-09-03', '2024-09-03', 1),
(21, 2, 9, 1, 120, '2024-09-03', '2024-09-04', 1),
(22, 3, 6, 1, 100, '2024-09-03', '2024-09-18', 0),
(23, 3, 9, 1, 120, '2024-09-03', '2024-09-04', 1),
(24, 2, 3, 1, 80, '2024-09-03', '2024-09-10', 1),
(25, 2, 5, 1, 100, '2024-09-03', '2024-09-18', 0),
(27, 2, 8, 1, 100, '2024-09-05', '2024-09-20', 0),
(28, 3, 4, 1, 90, '2024-09-28', '2024-10-13', 0);

-- --------------------------------------------------------

--
-- Table structure for table `order_payment`
--

CREATE TABLE `order_payment` (
  `payment_id` int(11) NOT NULL,
  `order_id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `payment_amount` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_payment`
--

INSERT INTO `order_payment` (`payment_id`, `order_id`, `user_id`, `payment_amount`) VALUES
(1, 27, 2, 100),
(2, 28, 3, 90);

-- --------------------------------------------------------

--
-- Table structure for table `user_list`
--

CREATE TABLE `user_list` (
  `user_id` int(10) NOT NULL,
  `username` varchar(20) NOT NULL,
  `user_email` varchar(30) NOT NULL,
  `user_password` varchar(30) NOT NULL,
  `is_deleted` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_list`
--

INSERT INTO `user_list` (`user_id`, `username`, `user_email`, `user_password`, `is_deleted`) VALUES
(1, 'defg', 'defg@gmail.com', '54321', 0),
(2, 'user', 'user@gmail.com', '12345', 0),
(3, 'Husain', 'hjc@gmail.com', '123456', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `book_cart`
--
ALTER TABLE `book_cart`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `book_image`
--
ALTER TABLE `book_image`
  ADD PRIMARY KEY (`image_id`);

--
-- Indexes for table `book_list`
--
ALTER TABLE `book_list`
  ADD PRIMARY KEY (`book_id`);

--
-- Indexes for table `book_order`
--
ALTER TABLE `book_order`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `order_payment`
--
ALTER TABLE `order_payment`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `user_list`
--
ALTER TABLE `user_list`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `book_cart`
--
ALTER TABLE `book_cart`
  MODIFY `cart_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `book_image`
--
ALTER TABLE `book_image`
  MODIFY `image_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `book_list`
--
ALTER TABLE `book_list`
  MODIFY `book_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `book_order`
--
ALTER TABLE `book_order`
  MODIFY `order_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `order_payment`
--
ALTER TABLE `order_payment`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user_list`
--
ALTER TABLE `user_list`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
