<!DOCTYPE HTML>
<html>

<head>
    <title>PHPJabbers.com | Free Book Online Store Website Template</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" href="assets/css/main.css" />
    <noscript>
        <link rel="stylesheet" href="assets/css/noscript.css" />
    </noscript>
</head>

<body class="is-preload">
    <!-- Wrapper -->
    <div id="wrapper">

        <!-- Header -->
        <header id="header">
            <div class="inner">

                <!-- Logo -->
                <a href="index.php" class="logo">
                    <span class="fa fa-book"></span> <span class="title">Book Online Store Website</span>
                </a>

                <!-- Nav -->
                <nav>
                    <ul>
                        <li><a href="#menu">Menu</a></li>
                    </ul>
                </nav>

            </div>
        </header>

        <!-- Menu -->
        <nav id="menu">
            <h2>Menu</h2>

            <ul>
                <li><a href="index.php">Home</a></li>

                <li><a href="products.php">Products</a></li>

                <li><a href="Cart.php">Cart</a></li>

                <li>
                    <a href="#" class="dropdown-toggle">About</a>

                    <ul>
                        <li><a href="about.php">About Us</a></li>
                        <li><a href="blog.php">Blog</a></li>
                        <li><a href="testimonials.php" class="active">Testimonials</a></li>
                        <li><a href="terms.php">Terms</a></li>
                    </ul>
                </li>

                <li><a href="contact.php">Contact Us</a></li>
            </ul>
        </nav>

        <!-- Main -->
        <div id="main">
            <div class="inner">
                <h1>Testimonials</h1>

                <div class="image main">
                    <img src="images/banner-image-3-1920x500.jpg" class="img-fluid" alt="" />
                </div>

                <div class="row">
                    <div class="col-sm-6 text-center">
                        <p class="m-n"><em>"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sunt delectus
                                mollitia, debitis architecto recusandae? Quidem ipsa, quo, labore minima enim similique,
                                delectus ullam non laboriosam laborum distinctio repellat quas deserunt voluptas
                                reprehenderit dignissimos voluptatum deleniti saepe. Facere expedita autem quos."</em>
                        </p>

                        <p><strong> - John Doe</strong></p>
                    </div>

                    <div class="col-sm-6 text-center">
                        <p class="m-n"><em>"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sunt delectus
                                mollitia, debitis architecto recusandae? Quidem ipsa, quo, labore minima enim similique,
                                delectus ullam non laboriosam laborum distinctio repellat quas deserunt voluptas
                                reprehenderit dignissimos voluptatum deleniti saepe. Facere expedita autem quos."</em>
                        </p>

                        <p><strong>- John Doe</strong> </p>
                    </div>
                </div>

                <br>

                <div class="row">
                    <div class="col-sm-6 text-center">
                        <p class="m-n"><em>"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sunt delectus
                                mollitia, debitis architecto recusandae? Quidem ipsa, quo, labore minima enim similique,
                                delectus ullam non laboriosam laborum distinctio repellat quas deserunt voluptas
                                reprehenderit dignissimos voluptatum deleniti saepe. Facere expedita autem quos."</em>
                        </p>

                        <p><strong> - John Doe</strong></p>
                    </div>

                    <div class="col-sm-6 text-center">
                        <p class="m-n"><em>"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sunt delectus
                                mollitia, debitis architecto recusandae? Quidem ipsa, quo, labore minima enim similique,
                                delectus ullam non laboriosam laborum distinctio repellat quas deserunt voluptas
                                reprehenderit dignissimos voluptatum deleniti saepe. Facere expedita autem quos."</em>
                        </p>

                        <p><strong>- John Doe</strong> </p>
                    </div>
                </div>

                <br>

                <div class="row">
                    <div class="col-sm-6 text-center">
                        <p class="m-n"><em>"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sunt delectus
                                mollitia, debitis architecto recusandae? Quidem ipsa, quo, labore minima enim similique,
                                delectus ullam non laboriosam laborum distinctio repellat quas deserunt voluptas
                                reprehenderit dignissimos voluptatum deleniti saepe. Facere expedita autem quos."</em>
                        </p>

                        <p><strong> - John Doe</strong></p>
                    </div>

                    <div class="col-sm-6 text-center">
                        <p class="m-n"><em>"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sunt delectus
                                mollitia, debitis architecto recusandae? Quidem ipsa, quo, labore minima enim similique,
                                delectus ullam non laboriosam laborum distinctio repellat quas deserunt voluptas
                                reprehenderit dignissimos voluptatum deleniti saepe. Facere expedita autem quos."</em>
                        </p>

                        <p><strong>- John Doe</strong> </p>
                    </div>
                </div>


            </div>
        </div>

        <!-- Footer -->
        <footer id="footer">
            <div class="inner">
                <section>
                    <ul class="icons">
                        <li><a href="#" class="icon style2 fa-twitter"><span class="label">Twitter</span></a></li>
                        <li><a href="#" class="icon style2 fa-facebook"><span class="label">Facebook</span></a></li>
                        <li><a href="#" class="icon style2 fa-instagram"><span class="label">Instagram</span></a></li>
                        <li><a href="#" class="icon style2 fa-linkedin"><span class="label">LinkedIn</span></a></li>
                    </ul>

                    &nbsp;
                </section>

                <ul class="copyright">
                    <li>Copyright © 2020 Company Name </li>
                    <li>Template by: <a href="https://www.phpjabbers.com/">PHPJabbers.com</a></li>
                </ul>
            </div>
        </footer>

    </div>

    <!-- Scripts -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/jquery.scrolly.min.js"></script>
    <script src="assets/js/jquery.scrollex.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>

</html>